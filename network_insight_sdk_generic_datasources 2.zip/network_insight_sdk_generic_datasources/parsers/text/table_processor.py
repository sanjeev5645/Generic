# Copyright 2019 VMware, Inc.
# SPDX-License-Identifier: BSD-2-Clause


class TableProcessor(object):

    def process_tables(self, data):
        type(self)
        return data
